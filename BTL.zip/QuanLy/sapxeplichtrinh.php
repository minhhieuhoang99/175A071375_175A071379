<?php require ("dautrang.php"); ?>
    <main>
    <?php require ("nav.php"); ?>
      <div class="grid-container">
      <?php require ("navquanly.php"); ?>
        <div class="grid-item item2">
          <div class="grid-container-table">
            <div class="item item-table1"><h3 >SẮP XẾP LỊCH TRÌNH</h3></div>
            <div class="item item-table2"><p>Mã lớp học phần:</p></div>
            <div class="item item-table3">
              <input type="text" name="FirstName" value="" class="textbox" />
            </div>
            <div class="item item-table2"><p>Mã lớp môn học:</p></div>
            <div class="item item-table3">
              <input type="text" name="FirstName" value="" class="textbox" />
            </div>
            <div class="item item-table2"><p>Giảng viên:</p></div>
            <div class="item item-table3">
              <input type="text" name="FirstName" value="" class="textbox" />
            </div>
            <div class="item item-table1" style="text-align: center;">
              <input type="submit" class="submit" value="Xác nhận" />
            </div>
          </div>
          </div>

    </main>
    <?php require ("chantrang.php"); ?>
