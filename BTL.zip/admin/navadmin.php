<div class="grid-item item1">
          <ul class="list-group">
            <li class="list-group-item " style="text-align: center;">
              <p style="margin:auto">MAIN MENU</p>
            </li>
            <li class="list-group-item ">
              <a href="#SubMenu1" data-toggle="collapse" data-parent="#SubMenu1"
                >Quản lý tài khoản</a
              >
              <div class="collapse list-group-submenu" id="SubMenu1">
                <a
                  href="../admin/admintaotk.php"
                  class="list-group-item"
                  data-parent="#SubMenu1"
                  style="margin-top: 20px;"
                  >Tạo tài khoản</a
                >
                <a
                  href="../admin/adminimport.php"
                  class="list-group-item"
                  data-parent="#SubMenu1"
                  >Tạo tài khoản theo danh sách</a
                >
                <a
                  href="../admin/admin_CNtk.php"
                  class="list-group-item"
                  data-parent="#SubMenu1"
                >
                  Cập nhật tài khoản</a
                >
              </div>
            </li>
          </ul>
        </div>