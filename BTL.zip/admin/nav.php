<div class="grid-nav">
        <div class="grid-item item1" style="margin-left: 17px;">
          <span id="navbar"><a href="/CMCSoft.IU.Web.Info/Home.aspx" >Trang chủ</a> |
            
            <a href="./support/default.aspx" target="_blank">Hỏi đáp</a> | 
        </div>
        <div class="grid-item item2"></div>
        <div class="grid-item item3" style="margin-right: 20px;">
          <a href="/CMCSoft.IU.Web.Info/WebHelp/NewProject1.htm" target="_blank">
            Trợ giúp</a>
      <select name="PageHeader1$drpNgonNgu" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;PageHeader1$drpNgonNgu\&#39;,\&#39;\&#39;)&#39;, 0)" id="PageHeader1_drpNgonNgu" style="width:50px;Z-INDEX: 0">
      <option selected="selected" value="2D8E12D246D64A7BB3B89CC6484D2776">VN</option>
      </select>
        </span></div>  
      </div>