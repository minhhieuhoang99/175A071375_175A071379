<?php require ("dautrang.php"); ?>
    <main>
      <div class="grid-container">
      <?php require ("navadmin.php"); ?>
        <div class="grid-item item2"></div>
        <div class="grid-item item3"></div>
      </div>
      
    </main>
    <?php require ("chantrang.php"); ?>
